<?php
/**
 * Displays footer site info
 *
 * @package web-wave
 * @version 1.0.1
 */

?>

<!-- Bottom Bar -->
<div class="tm-bottom-bar">
	<div class="container">
		<div class="copyright">

			<?php $copyright_text = web_wave_get_option( 'copyright_text' ); 
						    
	        if ( ! empty( $copyright_text ) ) : ?>
	    
	           <?php echo wp_kses_data( $copyright_text ); ?>
	    
	        <?php endif; ?>

	            <a href="<?php echo esc_url( __( 'https://www.wordpress.org/', 'web-wave' ) ); ?>">  <?php printf( esc_html__( ' Proudly powered by %s ', 'web-wave' ), 'WordPress ' ); ?>
							    </a>
								<span class="sep"> <?php esc_html_e('|','web-wave') ?>  </span>

				<?php printf( esc_html__( ' Theme: %1$s by %2$s.', 'web-wave' ), 'Web Wave', '<a href="https://www.themesara.com/" target="_blank">ThemeSara</a>' ); ?>

		</div>
		<div class="bottom-nav">
			<?php echo do_action('web_wave_footer_menu'); ?>
		</div>
	</div>
</div><!-- /Bottom Bar -->