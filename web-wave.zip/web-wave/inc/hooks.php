<?php


//=============================================================
// Social Icon hook of the theme
//=============================================================
if ( ! function_exists( 'web_wave_top_header_social_icon_action' ) ) :
    
    function web_wave_top_header_social_icon_action() { ?>
        <div class="col-md-6 col-sm-12 social-links">
            <?php if ( has_nav_menu( 'social' ) ) : ?>
                   <?php wp_nav_menu( array(
                        'theme_location'  => 'social',
                        'menu_id'         => '',
                        'menu_class'      => '',
                        'container_class' => 'social-icons',
                        
                    ) ); 
                    ?>
                 
               
            <?php endif; ?>
        </div>
    <?php }

endif;

add_action('web_wave_top_header_social_icon', 'web_wave_top_header_social_icon_action');

//=============================================================
// Footer Menu hook of the theme
//=============================================================
if ( ! function_exists( 'web_wave_footer_menu_action' ) ) :
    
    function web_wave_footer_menu_action() { ?>

           <?php if ( has_nav_menu( 'social' ) ) : ?>
                   <?php wp_nav_menu( array(
                        'theme_location'  => 'footer-menu',
                        'menu_id'         => '',
                        'menu_class'      => '',
            ) ); 
             endif; 
         }

endif;

add_action('web_wave_footer_menu', 'web_wave_footer_menu_action');


//=============================================================
// Breadcrumb Options
//=============================================================
if ( ! function_exists( 'web_wave_breadcrumb_action' ) ) :
    function web_wave_breadcrumb_action() { 

    $breadcrumb_type = web_wave_get_option( 'breadcrumb_type' );

    if($breadcrumb_type == 'normal'): ?>

            <!-- Breadcrumb Header -->
      
          <?php Breadcrumb_trail(); ?>
         
        <!-- /Breadcrumb Header -->
	<?php
    endif; 
    }
endif;

add_action( 'web_wave_breadcrumb_options', 'web_wave_breadcrumb_action' );








/**
 * enqueue Script for admin dashboard.
 */

if (!function_exists('web_wave_widgets_backend_enqueue')) :
    function web_wave_widgets_backend_enqueue($hook)
    {
        if ('widgets.php' != $hook)
        {
            return;
        }

        wp_register_script('web-wave-custom-widgets', get_template_directory_uri() . '/themesara/assets/js/widget.js', array('jquery'), true);
        wp_enqueue_media();
        wp_enqueue_script('web-wave-custom-widgets');
    }

    add_action('admin_enqueue_scripts', 'web_wave_widgets_backend_enqueue');
endif;