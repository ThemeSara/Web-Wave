<?php
/**
 * Recommended plugins
 *
 * @package web-wave
 * @version 1.0.1
 */
if ( ! function_exists( 'web_wave_recommended_plugins' ) ) :
	/**
	 * Recommend plugins.
	 *
	 * @since 1.0.1
	 */
	function web_wave_recommended_plugins() {
		
		$plugins = array(

			array(
				'name'     => esc_html__( 'Themesara Tools', 'web-wave' ),
				'slug'     => 'themesara-toolset',
				'required' => false,
			),
	
		);
		tgmpa( $plugins );
	}
endif;
add_action( 'tgmpa_register', 'web_wave_recommended_plugins' );
